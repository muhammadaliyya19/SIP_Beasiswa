import React, { Component } from "react";
// import Evoting from "../contracts/Evoting.json";
import Beasiswa from "../contracts/Beasiswa.json";
import getWeb3 from "../getWeb3";

import { Button } from 'react-bootstrap';

import NavigationAdmin from './NavigationAdmin';
import Navigation from './Navigation';

import '../index.css';

class MyRegist extends Component {
  constructor(props) {
    super(props)

    this.state = {
      BeasiswaInstance: undefined,
      account: null,
      web3: null,
      AllBeasiswa : null,
      RegistSaya: null,
      jmlPendaftar: null,
      isOwner: false
    }
  }

  componentDidMount = async () => {
    // FOR REFRESHING PAGE ONLY ONCE -
    if (!window.location.hash) {
      window.location = window.location + '#loaded';
      window.location.reload();
    }

    try {
      // Get network provider and web3 instance.
      const web3 = await getWeb3();

      // Use web3 to get the user's accounts.
      const accounts = await web3.eth.getAccounts();

      // Get the contract instance.
      const networkId = await web3.eth.net.getId();
      const deployedNetwork = Beasiswa.networks[networkId];
      const instance = new web3.eth.Contract(
        Beasiswa.abi,
        deployedNetwork && deployedNetwork.address,
      );

      // Set web3, accounts, and contract to the state, and then proceed with an
      // example of interacting with the contract's methods.

      // this.setState({ web3, accounts, contract: instance }, this.runExample);
      this.setState({ BeasiswaInstance: instance, web3: web3, account: accounts[0] });

    let jumlah_beasiswa = await this.state.BeasiswaInstance.methods.getSumBeasiswa().call();
    let daftar_beasiswa = [];
    for (let i = 0; i < jumlah_beasiswa; i++) {
        let beasiswa = await this.state.BeasiswaInstance.methods.List_Beasiswa(i).call();
        daftar_beasiswa.push(beasiswa);
    }
      
      //   Populasi pendaftaran saya
    let jumlahPendaftar = await this.state.BeasiswaInstance.methods.getSumAllPendaftar().call();
    let ListPendaftaranSaya = [];
      for (let i = 0; i < jumlahPendaftar; i++) {
        let detailPendaftar = await this.state.BeasiswaInstance.methods.list_mahasiswa_pendaftar(i).call();        
        if (detailPendaftar.id_mhs == this.state.account) {
            detailPendaftar.namaBeasiswa = daftar_beasiswa[detailPendaftar.beasiswa_id].judul;
            ListPendaftaranSaya.push(detailPendaftar);
        }        
        // let id_mhs = await this.state.BeasiswaInstance.methods.Mhs(i).call();
        
      }
      this.setState({ RegistSaya: ListPendaftaranSaya });      

      this.setState({ AllBeasiswa: daftar_beasiswa });

    } catch (error) {
      // Catch any errors for any of the above operations.
      alert(
        `Failed to load web3, accounts, or contract. Check console for details.`,
      );
      console.error(error);
    }
  };

//   verifikasi = async event => {
//     await this.state.BeasiswaInstance.methods.memverifikasi(event.target.value).send({ from: this.state.account, gas: 1000000 });    
//     window.location.reload(false);
//   }

  render() {
    let myRegist;    
    if (this.state.RegistSaya) {
      myRegist = this.state.RegistSaya.map((pendaftaran) => {
        // SELEKSI Tombol Verif
        let tombol_verif = null;
        if (pendaftaran.is_verified==1) {
          tombol_verif = <Button className="btn btn-success">Anda Terverifikasi</Button>
        }else if(pendaftaran.is_verified==2){
          tombol_verif = <Button onClick={this.is_verified} value={pendaftaran.id_mhs} className="btn btn-warning">Maaf Anda Belum Lolos</Button>                
        }else{
          tombol_verif = <Button onClick={this.is_verified} value={pendaftaran.id_mhs} className="btn btn-danger">Data Belum Diverifikasi</Button>
        }

        return (
          <div className="candidate">
            <div className="candidateName">{pendaftaran.nama}</div>
            <div className="CandidateDetails">
              <div>NIM : {pendaftaran.nim}</div>
              <div>Alamat : {pendaftaran.alamat}</div>
              <div>IPK : {pendaftaran.ipk}</div>
              <div>Essay : {pendaftaran.essay}</div>
              <div>ID Beasiswa : {pendaftaran.beasiswa_id}</div>
              <div>Nama Beasiswa : {pendaftaran.namaBeasiswa}</div>
            </div>

            <div className="CandidateDetails">
            {tombol_verif}
            </div>
            <div><br></br></div>
          </div>
        );
      });
    }

    if (!this.state.web3) {
      return (
        <div className="CandidateDetails">
          <div className="CandidateDetails-title">
            <h1>
              Loading Web3, accounts, and contract..
            </h1>
          </div>
          {this.state.isOwner ? <NavigationAdmin /> : <Navigation />}
        </div>
      );
    }

    // if (!this.state.isOwner) {
    //   return (
    //     <div className="CandidateDetails">
    //       <div className="CandidateDetails-title">
    //         <h1>
    //           HANYA ADMIN YANG BISA MENGAKSES
    //         </h1>
    //       </div>
    //       {this.state.isOwner ? <NavigationAdmin /> : <Navigation />}
    //     </div>
    //   );
    // }

    return (
      <div>
        <div className="CandidateDetails">
        {this.state.isOwner ? <NavigationAdmin /> : <Navigation />}
          <div className="CandidateDetails-title">
            <h1>
              PENDAFTARAN SAYA
            </h1>
          </div>
        </div>

        <div>
          {myRegist}
        </div>
      </div>
    );
  }
}

export default MyRegist;
