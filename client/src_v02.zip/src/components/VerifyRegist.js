import React, { Component, useState } from "react";
import Beasiswa from "../contracts/Beasiswa.json";
import getWeb3 from "../getWeb3";
import { Button } from 'react-bootstrap';

import '../index.css';

import NavigationAdmin from './NavigationAdmin';
import Navigation from './Navigation';
import { Link, useParams, useRoute } from 'react-router-dom';

class VerifyRegist extends Component {
  constructor(props) {
    super(props)

    this.state = {
      BeasiswaInstance: undefined,
      account: null,
      web3: null,
      BeasiswaId : null,
      MahasiswaId : null,
      AllBeasiswa : null,
      SemuaRegist: null,
      jmlPendaftar: null,
      isOwner: false
    }
  }

  // getBeasiswaId(){    
  //   const { id_beasiswa } = useParams();
  //   console.log(id_beasiswa);
  //   return {id_beasiswa}
  // }
  
  componentDidMount = async () => {
    // FOR REFRESHING PAGE ONLY ONCE -
    if (!window.location.hash) {
      window.location = window.location + '#loaded';
      window.location.reload();
    }

    try {
      // Get network provider and web3 instance.
      const web3 = await getWeb3();

      // Use web3 to get the user's accounts.
      const accounts = await web3.eth.getAccounts();

      // Get the contract instance.
      const networkId = await web3.eth.net.getId();
      const deployedNetwork = Beasiswa.networks[networkId];
      const instance = new web3.eth.Contract(
        Beasiswa.abi,
        deployedNetwork && deployedNetwork.address,
      );

      // Set web3, accounts, and contract to the state, and then proceed with an
      // example of interacting with the contract's methods.

      // this.setState({ web3, accounts, contract: instance }, this.runExample);
      this.setState({ BeasiswaInstance: instance, web3: web3, account: accounts[0] });

      // Get params
      const this_params = this.props.match.params;
      // console.log("All",this_params);
      // console.log("Beasiswa",this_params.id_beasiswa);
      // console.log("Mahasiswa",this_params.id_mahasiswa);
      this.setState({ BeasiswaId: this_params.id_beasiswa });
      
    let jumlah_beasiswa = await this.state.BeasiswaInstance.methods.getSumBeasiswa().call();
    let daftar_beasiswa = [];
    for (let i = 0; i < jumlah_beasiswa; i++) {
        let beasiswa = await this.state.BeasiswaInstance.methods.List_Beasiswa(i).call();
        daftar_beasiswa.push(beasiswa);
    }
      
      //   Populasi pendaftaran saya
    let jumlahPendaftar = await this.state.BeasiswaInstance.methods.getSumAllPendaftar().call();
    let ListPendaftaran = [];
      for (let i = 0; i < jumlahPendaftar; i++) {
        let detailPendaftar = await this.state.BeasiswaInstance.methods.list_mahasiswa_pendaftar(i).call();        
        
            detailPendaftar.namaBeasiswa = daftar_beasiswa[detailPendaftar.beasiswa_id].judul;
            ListPendaftaran.push(detailPendaftar);
        // let id_mhs = await this.state.BeasiswaInstance.methods.Mhs(i).call();
        
      }
      this.setState({ SemuaRegist: ListPendaftaran });      

      this.setState({ AllBeasiswa: daftar_beasiswa });

      const owner = await this.state.BeasiswaInstance.methods.Admin().call();
      if (this.state.account === owner) {
        this.setState({ isOwner: true });
      }
      
    } catch (error) {
      // Catch any errors for any of the above operations.
      alert(
        `Failed to load web3, accounts, or contract. Check console for details.`,
      );
      console.error(error);
    }
  };

  verifikasi(e){
    console.log(e.target.dataset.mhs);
    console.log(e.target.dataset.status);
    let mhs = e.target.dataset.mhs;
    let status = e.target.dataset.status;

    this.state.BeasiswaInstance.methods.verify_mahasiswa(mhs, status).send({ from: this.state.account, gas: 1000000 });    
    window.location.reload(false);
  }

  // verifikasi = async event => {
  //   console.log(event);
  //   // await this.state.BeasiswaInstance.methods.verify_mahasiswa(event.target.value).send({ from: this.state.account, gas: 1000000 });
  //   // window.location.reload(false);
  // }

  render() {
    // let id;    
    let idB = this.state.BeasiswaId;
    let allRegist = [];    
    if (this.state.SemuaRegist) {
      for (let j = 0; j < this.state.SemuaRegist.length; j++) {
        
        if(this.state.SemuaRegist[j].beasiswa_id == idB){
          let statusVerif = null;
          let buttonVerif = [];
          switch (this.state.SemuaRegist[j].is_verified) {
            case 1:
              statusVerif = <span className="text-success">Lolos Verifikasi</span>
              buttonVerif = null
              break;
            case 2:
              statusVerif = <span className="text-danger">Tidak Lolos Verifikasi</span>
              buttonVerif = null
              break;
            default:
              statusVerif = <span className="text-primary">Belum Diverifikasi</span>
              // buttonVerif.push(<Button className="btn btn-sm btn-success" onClick={this.verifikasi.bind(this, j, 1)}>Lolos Verifikasi</Button>); 
              // buttonVerif.push(" || "); 
              // buttonVerif.push(<Button className="btn btn-sm btn-danger" onClick={this.verifikasi.bind(this, j, 2)}>Tidak Lolos Verifikasi</Button>);               
              buttonVerif.push(<Button className="btn btn-sm btn-success" data-mhs={j} data-status={1} onClick={this.verifikasi}>Lolos Verifikasi</Button>); 
              buttonVerif.push(" || "); 
              buttonVerif.push(<Button className="btn btn-sm btn-danger" data-mhs={j} data-status={2} onClick={this.verifikasi}>Tidak Lolos Verifikasi</Button>);               
              break;
          }
          allRegist.push(
            <div className="candidate">
              <div className="candidateName">{this.state.SemuaRegist[j].nama} || {statusVerif}</div>
              <div className="CandidateDetails">            
                <div>Beasiswa Params : {this.state.BeasiswaId}</div>
                <div>NIM : {this.state.SemuaRegist[j].nim}</div>
                <div>Alamat : {this.state.SemuaRegist[j].alamat}</div>
                <div>IPK : {this.state.SemuaRegist[j].ipk}</div>
                <div>Motto : {this.state.SemuaRegist[j].essay}</div>
                <div>ID Beasiswa : {this.state.SemuaRegist[j].beasiswa_id}</div>
                <div>Nama Beasiswa : {this.state.SemuaRegist[j].namaBeasiswa}</div>
              </div>
              <div>
              {buttonVerif}                
              </div>              
            </div>
          );
        }        
      }      
    }

    if (!this.state.web3) {
      return (
        <div className="CandidateDetails">
          <div className="CandidateDetails-title">
            <h1>
              Loading Web3, accounts, and contract..
            </h1>
          </div>
          {this.state.isOwner ? <NavigationAdmin /> : <Navigation />}
        </div>
      );
    }

    if (!this.state.isOwner) {
      return (        
            <h1>
              HANYA ADMIN YANG BISA MENGAKSES
            </h1>
      );
    }

    return (
      <div>
        <div className="CandidateDetails">
        {this.state.isOwner ? <NavigationAdmin /> : <Navigation />}
          <div className="CandidateDetails-title">
            <h1>
              VERIFIKASI PENDAFTARAN {this.state.BeasiswaId}
            </h1>
          </div>
        </div>

        <div>
          {allRegist}
        </div>
      </div>
    );
  }
}

export default VerifyRegist;
